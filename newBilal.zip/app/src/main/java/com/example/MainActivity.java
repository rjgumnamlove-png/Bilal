package com.example;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class MainActivity extends Activity {

    private static final String TAG = "RJ_Bilal_UnityAds";
    public static final String GAME_ID = "6194905";
    public static final String INTERSTITIAL_UNIT = "Interstitial_Android";
    public static final String REWARDED_UNIT = "Rewarded_Android";
    private static final boolean TEST_MODE = false;

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Register AndroidBridge JavascriptInterface
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://wa.me") || url.startsWith("whatsapp:") || !url.startsWith("file:///android_asset/"))) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        Log.e(TAG, "Cannot launch external URL: " + url, e);
                        Toast.makeText(MainActivity.this, "Unable to open link", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                }
                return false;
            }
        });

        // Load original HTML
        webView.loadUrl("file:///android_asset/index.html");

        // Initialize Unity Ads with Game ID 6194905
        initUnityAds(GAME_ID);
    }

    public void initUnityAds(String gameId) {
        final String effectiveGameId = (gameId != null && !gameId.trim().isEmpty()) ? gameId.trim() : GAME_ID;
        if (!UnityAds.isInitialized()) {
            UnityAds.initialize(getApplicationContext(), effectiveGameId, TEST_MODE, new IUnityAdsInitializationListener() {
                @Override
                public void onInitializationComplete() {
                    Log.d(TAG, "Unity Ads initialized successfully with Game ID: " + effectiveGameId);
                    preloadAd(INTERSTITIAL_UNIT);
                    preloadAd(REWARDED_UNIT);
                }

                @Override
                public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                    Log.e(TAG, "Unity Ads initialization failed: [" + error + "] " + message);
                }
            });
        } else {
            preloadAd(INTERSTITIAL_UNIT);
            preloadAd(REWARDED_UNIT);
        }
    }

    public void preloadAd(String placementId) {
        UnityAds.load(placementId, new IUnityAdsLoadListener() {
            @Override
            public void onUnityAdsAdLoaded(String placementId) {
                Log.d(TAG, "Ad loaded for placement: " + placementId);
            }

            @Override
            public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                Log.w(TAG, "Ad failed to load: [" + placementId + "] " + message);
            }
        });
    }

    public void showAd(String placementId) {
        UnityAds.show(MainActivity.this, placementId, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
            @Override
            public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                Log.e(TAG, "Unity Ads show failed for [" + placementId + "]: " + message);
                Toast.makeText(MainActivity.this, "Ad loading... Please try again in a moment", Toast.LENGTH_SHORT).show();
                preloadAd(placementId);
            }

            @Override
            public void onUnityAdsShowStart(String placementId) {
                Log.d(TAG, "Unity Ads show started for: " + placementId);
            }

            @Override
            public void onUnityAdsShowClick(String placementId) {
                Log.d(TAG, "Unity Ads clicked for: " + placementId);
            }

            @Override
            public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                Log.d(TAG, "Unity Ads show completed for: " + placementId + " with state: " + state);
                preloadAd(placementId);
            }
        });
    }

    public void initUnityFromBridge(String gameId) {
        runOnUiThread(() -> {
            Log.d(TAG, "initUnityFromBridge: " + gameId);
            initUnityAds(gameId);
        });
    }

    public void showInterstitialFromBridge(String placementId) {
        runOnUiThread(() -> {
            Log.d(TAG, "showInterstitialFromBridge: " + placementId);
            String id = (placementId != null && !placementId.trim().isEmpty()) ? placementId.trim() : INTERSTITIAL_UNIT;
            showAd(id);
        });
    }

    public void showRewardedFromBridge(String placementId) {
        runOnUiThread(() -> {
            Log.d(TAG, "showRewardedFromBridge: " + placementId);
            String id = (placementId != null && !placementId.trim().isEmpty()) ? placementId.trim() : REWARDED_UNIT;
            showAd(id);
        });
    }

    public void loadBannerFromBridge(String placementId) {
        Log.d(TAG, "loadBannerFromBridge: " + placementId);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
