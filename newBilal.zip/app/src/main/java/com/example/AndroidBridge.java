package com.example;

import android.webkit.JavascriptInterface;

/**
 * JavaScript Interface bridge between WebView web application and Android native Unity Ads.
 */
public class AndroidBridge {

    private final MainActivity activity;

    public AndroidBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void initUnity(String gameId) {
        if (activity != null) {
            activity.initUnityFromBridge(gameId);
        }
    }

    @JavascriptInterface
    public void showInterstitial(String placementId) {
        if (activity != null) {
            activity.showInterstitialFromBridge(placementId);
        }
    }

    @JavascriptInterface
    public void showRewarded(String placementId) {
        if (activity != null) {
            activity.showRewardedFromBridge(placementId);
        }
    }

    @JavascriptInterface
    public void loadBanner(String placementId) {
        if (activity != null) {
            activity.loadBannerFromBridge(placementId);
        }
    }
}
